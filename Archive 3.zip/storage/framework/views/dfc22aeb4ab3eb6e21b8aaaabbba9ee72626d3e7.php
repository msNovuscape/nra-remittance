<?php $__env->startSection('content'); ?>
    <section class="innerpage section-padding-50 committee">
        <div class="container">
            <h1>Our Members</h1>
            <article class="innerpage-article-content table-data-content">
                <div class="table-responsive">
                    <table class="table bg-secondary th-border">
                        <thead>
                            <tr>
                                <th>S.N.</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Visit Website</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($member->organization); ?></td>
                                <td><?php echo e($member->address); ?></td>
                                <td><?php echo e($member->phone); ?></td>
                                <td><a href="<?php echo e($member->website_link); ?>" target="_blank">Link Here</a></td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                </div>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/member.blade.php ENDPATH**/ ?>