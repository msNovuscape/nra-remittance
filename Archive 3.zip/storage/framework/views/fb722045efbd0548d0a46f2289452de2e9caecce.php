<?php $__env->startSection('content'); ?>
    <section class="innepage gallery-content section-padding-50">
        <div class="container">
            <h1>Gallery</h1>

            <div class="grid grid-cols-4 grid-gap-30">
                <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card card--gallery">
                    <a href="<?php echo e(route('welcome.single_gallery',['id' => $gallery->id])); ?>">
                        <figure>
                            <img src="<?php echo e(asset( 'storage/' . $gallery->image_path )); ?>" alt="<?php echo e($gallery->title); ?>">
                        </figure>
                    </a>
                    <article class="card__body card--gallery__body">
                        <a href="<?php echo e(route('welcome.single_gallery',['id' => $gallery->id])); ?>" class="card__title"><?php echo e($gallery->title); ?></a>
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No data available!</p>
                <?php endif; ?>
                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/gallery.blade.php ENDPATH**/ ?>