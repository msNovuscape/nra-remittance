<?php $__env->startSection('content'); ?>
    <section class="innerpage section-padding-50 msg-central-bank">
        <div class="container">
            <h1>Message From Central Bank</h1>
            <?php if($message->isNotEmpty()): ?>
            
            <figure>
                <img src="<?php echo e(asset( 'storage/' . $message->first()->image_path )); ?>" alt="">
            </figure>
            <article class="innerpage-article-content">
            <b><?php echo e($message->first()->title); ?></b>
                <p><?php echo e($message->first()->description); ?></p>
                
            </article>
            <?php else: ?>
            <article class="innerpage-article-content">
                <p>Message is currently empty!</p>
                
            </article>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/central_bank_message.blade.php ENDPATH**/ ?>