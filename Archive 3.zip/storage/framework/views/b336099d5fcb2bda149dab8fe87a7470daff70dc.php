<?php $__env->startSection('content'); ?>
        <!-- Teams start -->
        <section class="teams-list section-padding-50">
            <div class="container">
                <article class="section__header">
                    <h1>Our Officer</h1>
                </article>
                <div class="grid grid-cols-3 grid-gap-30">
                    <?php $__currentLoopData = $executive_committees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executive_committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card card--team">
                        <figure class="card__img">
                            <img src="<?php echo e(asset( 'storage/' . $executive_committee->image_path )); ?>" class="circle" alt="team">
                        </figure>
                        <article class="card__body text-center">
                            <h3><?php echo e($executive_committee->first_name); ?> <?php echo e($executive_committee->last_name); ?></h3>
                            <div class="card__meta flex flex-content-between">
                                <div class="card__meta-designation"><?php echo e($executive_committee->last_name); ?> <br> <span class="text"><?php echo e($executive_committee->designation); ?></span></div>
                                <div class="card__meta-designation">Location <br> <span class="text"><?php echo e($executive_committee->address); ?>,<?php echo e($executive_committee->city); ?>,<?php echo e($executive_committee->country); ?></span></div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </section>
        <!-- Teams end -->

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/committee.blade.php ENDPATH**/ ?>