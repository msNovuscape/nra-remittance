<?php $__env->startSection('content'); ?>
<section class="innerpage section-padding-50 msg-central-bank">
        <div class="container">
            <h1><?php echo e($single_gallery->title); ?></h1>
            <span class="card__date"><?php echo e($single_gallery->created_at->format('M j, Y')); ?></span>
            <?php if($single_gallery->count() > 0): ?>
            <figure>
                <img src="<?php echo e(asset( 'storage/' . $single_gallery->image_path )); ?>">
            </figure>
            <article class="innerpage-article-content">
                <p><?php echo e($single_gallery->description); ?></p>
                
            </article>
            <?php else: ?>
            <article class="innerpage-article-content">
                <p>Data not available!</p>
                
            </article>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/single_gallery.blade.php ENDPATH**/ ?>