<?php $__env->startSection('content'); ?>
    <section class="innerpage news-list-page section-padding-50">
        <div class="container">
            <h1>News</h1>

            <div class="grid grid-cols-3 grid-gap-30">
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card card--news-box">
                    <a href="<?php echo e(route('welcome.single_news',['id' => $new->id])); ?>">
                        <figure>
                            <img src="<?php echo e(asset( 'storage/' . $new->image_path )); ?>" alt="Image unavailable">
                        </figure>
                    </a>
                    <article class="card__body card--news-box__body">
                        <a href="<?php echo e(route('welcome.single_news',['id' => $new->id])); ?>" class="card__title"><?php echo e($new->title); ?></a>
                        <span class="card__date"><?php echo e($new->created_at->format('M j, Y')); ?></span>
                        <p><?php echo e(str_limit(strip_tags($new->description), 110)); ?></p>
                            <?php if(strlen(strip_tags($new->description)) > 110): ?>
                            <a href="<?php echo e(route('welcome.single_news',['id' => $new->id])); ?>" class="btn btn-outline-third pill">Read More <i class="fa fa-long-arrow-right"></i></a>
                            <?php endif; ?>
                        
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Data not available.</p>
                <?php endif; ?>
                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/news_and_update.blade.php ENDPATH**/ ?>