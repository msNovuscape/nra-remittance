<?php $__env->startSection('content'); ?>
    <section class="innerpage section-padding-50 arts-regulation">
        <div class="container">
            <h1>Acts & Regulations</h1>
            <?php if($acts->isNotEmpty()): ?>
            <article class="innerpage-article-content">
                <p><?php echo e($acts->first()->title); ?></p>
                <p><?php echo e($acts->first()->description); ?></p> 
                <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio!</p> -->
            </article>
            <?php else: ?>
            <article class="innerpage-article-content">
                <p>There are no any data available!</p>
            </article>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/acts_and_regulations.blade.php ENDPATH**/ ?>