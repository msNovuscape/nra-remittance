<?php $__env->startSection('content'); ?>
    Remmitance overview content goes here
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra/resources/views/frontend/remmitance_overview.blade.php ENDPATH**/ ?>