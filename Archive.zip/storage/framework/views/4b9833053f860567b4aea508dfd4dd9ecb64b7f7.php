<?php $__env->startSection('content'); ?>
    <section class="innerpage section-padding-50 msg-central-bank">
        <div class="container">
            <h1>Message From Central Bank</h1>
            <figure>
                <img src="https://cdn.pixabay.com/photo/2021/06/13/07/33/mountain-pass-6332476_960_720.jpg" alt="">
            </figure>
            <article class="innerpage-article-content">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam necessitatibus id eaque, incidunt temporibus nemo iste perspiciatis repellat quibusdam. Dolorum laboriosam, recusandae error magni id voluptas quasi provident delectus minus!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio!</p>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/central_bank_message.blade.php ENDPATH**/ ?>