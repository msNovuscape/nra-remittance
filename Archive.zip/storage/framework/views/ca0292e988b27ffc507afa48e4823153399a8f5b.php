<!--

=========================================================
* Now UI Dashboard - v1.5.0
=========================================================

* Product Page: https://www.creative-tim.com/product/now-ui-dashboard
* Copyright 2019 Creative Tim (http://www.creative-tim.com)

* Designed by www.invisionapp.com Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

-->

<?php $__env->startSection('title'); ?>
  List <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>
<ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("add_exchange_rates")); ?>">
                  Add exchange rate
                </a>
              </li>
</ul>
<form id = "search_form" method = "POST" action = "<?php echo e(route('search_by_date')); ?>">
<?php echo e(csrf_field()); ?>

              <div class="input-group no-border">
            
                <input id = "date" type="date" name="date" value = <?php echo e($date); ?> class="form-control" placeholder="Search..." required>
                <div class="input-group-append">
                  <div id = "search" class="input-group-text">
                    <i class="now-ui-icons ui-1_zoom-bold"></i>
                  </div>
                </div>
              </div>
            </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
            <div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div> <!-- end .flash-message -->
              <div class="card-header">
                <h4 class="card-title"> <?php echo e($title); ?></h4>
                <div  class="col-md-2" style = "margin-left:85%">
                      <button class="btn btn-primary" onclick="window.location='<?php echo e(route("add_exchange_rates")); ?>'">Add new</button>
                </div>
         
  
             
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Currency
                      </th>
                      <th>
                        Unit
                      </th>
                      <th>
                        Buying Rate
                      </th>
                      <th>
                        Selling Rate
                      </th>
                      <th class="text-right">
                        Action
                      </th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $exchange_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange_rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                          <?php echo e($exchange_rate->currency); ?>

                        </td>
                        <td>
                        1
                        </td>
                        <td>
                        <?php echo e($exchange_rate->buying_rate); ?>

                        </td>
                        <td>
                        <?php echo e($exchange_rate->selling_rate); ?>

                        </td>
                        <td class="text-right">
                        <a  href="<?php echo e(route('edit_exchange_rate',['id' => $exchange_rate->id])); ?>"><i data-toggle="tooltip" data-placement="top" title="Edit" class="far fa-edit"></i></a>&nbsp;&nbsp;<a onclick="return confirm('Are you sure to delete this item?')" href = "<?php echo e(route('delete_exchange_rate',['id' => $exchange_rate->id])); ?>"><i data-toggle="tooltip" data-placement="top" title="Delete" class="far fa-trash-alt"></i></a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                    
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>

$( "#search" ).click(function() {
   $( "#search_form" ).submit();
  // if(date != '')
  //       {
  //           $.ajax({
  //               url: '<?php echo e(route('search_by_date')); ?>',
  //               method:"POST",
  //               data:{date:date,"_token": "<?php echo e(csrf_token()); ?>"},
  //               success:function(data)
  //               {
  //                   alert('success');
  //               }
  //           });
  //       }
  //       else
  //       {
  //           alert("Please Select the Date");
  //       }
});
        
   
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra/resources/views/admin/exchange_rates/index.blade.php ENDPATH**/ ?>