<?php $__env->startSection('content'); ?>
    Contact content goes here
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra/resources/views/frontend/contact.blade.php ENDPATH**/ ?>