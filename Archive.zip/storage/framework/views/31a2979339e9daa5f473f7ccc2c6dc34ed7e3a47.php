<!--

=========================================================
* Now UI Dashboard - v1.5.0
=========================================================

* Product Page: https://www.creative-tim.com/product/now-ui-dashboard
* Copyright 2019 Creative Tim (http://www.creative-tim.com)

* Designed by www.invisionapp.com Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

-->

<?php $__env->startSection('title'); ?>
  List <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>
<ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("add_gallery")); ?>">
                  Add gallery
                </a>
              </li>
</ul>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
            <div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div> <!-- end .flash-message -->
              <div class="card-header">
                <h4 class="card-title"> <?php echo e($title); ?></h4>
                <div  class="col-md-2" style = "margin-left:85%">
                      <button class="btn btn-primary" onclick="window.location='<?php echo e(route("add_gallery")); ?>'">Add new</button>
                </div>
         
  
             
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Title
                      </th>
                      <th>
                        Description
                      </th>
                      <th>
                        Image
                      </th>

                      <th class="text-right">
                        Action
                      </th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td>
                            <?php echo e($gallery->title); ?>

                          </td>
                          <td>
                          <?php echo e($gallery->description); ?>

                          </td>
                          <td>
                           <img class="avatar border-gray" src="<?php echo e(asset( 'storage/' . $gallery->image_path )); ?>" alt = "No image">
                          </td>
                          
                          <td class="text-right">
                            <a  href="<?php echo e(route('edit_gallery',['id' => $gallery->id])); ?>"><i data-toggle="tooltip" data-placement="top" title="Edit" class="far fa-edit"></i></a>&nbsp;&nbsp;<a onclick="return confirm('Are you sure to delete this item?')" href = "<?php echo e(route('delete_gallery',['id' => $gallery->id])); ?>"><i data-toggle="tooltip" data-placement="top" title="Delete" class="far fa-trash-alt"></i></a>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra/resources/views/admin/gallery/index.blade.php ENDPATH**/ ?>