<?php $__env->startSection('content'); ?>
    <section class="innerpage section-padding-50 committee">
        <div class="container">
            <h1>Members</h1>
            <article class="innerpage-article-content table-data-content">
                <div class="table-responsive">
                    <table class="table bg-secondary th-border">
                        <thead>
                            <tr>
                                <th>S.N.</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Visit Website</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Sreejan</td>
                                <td>Nepal</td>
                                <td>9811111111</td>
                                <td><a href="#!" target="_blank">Link Here</a></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Sreejan</td>
                                <td>Nepal</td>
                                <td>9811111111</td>
                                <td><a href="#!" target="_blank">Link Here</a></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Sreejan</td>
                                <td>Nepal</td>
                                <td>9811111111</td>
                                <td><a href="#!" target="_blank">Link Here</a></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Sreejan</td>
                                <td>Nepal</td>
                                <td>9811111111</td>
                                <td><a href="#!" target="_blank">Link Here</a></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Sreejan</td>
                                <td>Nepal</td>
                                <td>9811111111</td>
                                <td><a href="#!" target="_blank">Link Here</a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/nra-remittance/resources/views/frontend/committee.blade.php ENDPATH**/ ?>