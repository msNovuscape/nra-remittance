@extends('frontend.master')

@section('content')
    News and update content goes here
@endsection