@extends('frontend.master')

@section('content')
    Contact content goes here
@endsection