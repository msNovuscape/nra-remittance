@extends('frontend.master')

@section('content')
    Gallery content goes here
@endsection