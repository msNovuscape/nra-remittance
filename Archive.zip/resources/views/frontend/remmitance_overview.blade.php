@extends('frontend.master')

@section('content')
    Remmitance overview content goes here
@endsection