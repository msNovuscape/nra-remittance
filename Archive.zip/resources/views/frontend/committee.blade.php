@extends('frontend.master')

@section('content')
    Committee content goes here
@endsection