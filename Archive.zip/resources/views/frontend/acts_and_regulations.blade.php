@extends('frontend.master')

@section('content')
    Acts and regulations content goes here
@endsection