@extends('frontend.master')

@section('content')
    <section class="innerpage section-padding-50 arts-regulation">
        <div class="container">
            <h1>Acts & Regulations</h1>
            <article class="innerpage-article-content">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio!</p>
                <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam necessitatibus id eaque, incidunt temporibus nemo iste perspiciatis repellat quibusdam. Dolorum laboriosam, recusandae error magni id voluptas quasi provident delectus minus!</p> -->
                <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis officiis voluptas animi aut aliquid quo voluptatem cumque blanditiis sed aspernatur, dolor aliquam nemo ea inventore, illum necessitatibus in illo odio!</p> -->
            </article>
        </div>
    </section>
@endsection