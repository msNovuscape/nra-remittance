@extends('frontend.master')

@section('content')
    Message from central bank goes here
@endsection